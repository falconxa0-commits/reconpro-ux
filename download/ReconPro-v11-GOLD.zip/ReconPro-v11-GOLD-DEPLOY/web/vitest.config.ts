import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  test: {
    environment: "jsdom",
    globals: {
      vi: true,
      describe: true,
      it: true,
      expect: true,
    },
    include: ["src/__tests__/**/*.test.{ts,tsx}"],
  },
});
