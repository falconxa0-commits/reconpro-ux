# ReconPro Enterprise

> **Eleven Blades. One Target. One Verdict.**

The full-spectrum security reconnaissance platform with AI-powered live analysis. 11 scanning modules, 40+ subcommands, z.ai streaming integration.

## Installation

```bash
pip install reconpro
```

Or from source:

```bash
git clone https://github.com/reconpro-security/reconpro.git
cd reconpro
pip install .
```

## Quick Start

```bash
# Scan with default modules (recon, vibesec, auth, chain, oblivion)
reconpro example.com

# Run all remote modules
reconpro example.com --all

# Pick specific modules
reconpro example.com --modules recon,auth,nhi

# Quick VibeSec benchmark only
reconpro vibesec example.com

# JSON output
reconpro example.com --json -o report.json

# Skip TLS verification
reconpro example.com --insecure

# Adjust timeout and rate limit
reconpro example.com --timeout 5 --rate-limit 5
```

## z.ai Live Stream Integration

ReconPro includes a built-in **z.ai live stream** integration that pipes scan findings through an AI analyst in real-time. **Zero configuration, no API keys required** — it auto-discovers credentials from your environment.

### How It Works

The `ZAIStreamClient` auto-discovers the z.ai API config from standard locations (`/etc/.z-ai-config`, `~/.z-ai-config`, or `./.z-ai-config`). It connects to the z.ai LLM via Server-Sent Events (SSE) and streams AI-powered security analysis token-by-token.

### CLI Commands

```bash
# Health check — verify z.ai connectivity
reconpro zai --health

# Free-form AI chat (streaming)
reconpro zai --chat "What is the most dangerous web vulnerability in 2025?"

# Scan a target and stream AI analysis of findings
reconpro zai example.com

# Non-streaming (wait for complete response)
reconpro zai example.com --no-stream

# Choose a different model
reconpro zai --model glm-4-plus --chat "Explain CSRF"
```

### Python API

```python
from reconpro.integrations import ZAIStreamClient

# Auto-discovers config — no API keys needed
client = ZAIStreamClient()

# Health check
result = client.health_check()
print(result)  # {'status': 'connected', 'latency_ms': 230.7, ...}

# Stream AI analysis of findings
findings = [
    {
        "title": "Missing X-Frame-Options",
        "severity": "high",
        "category": "headers",
        "module": "recon",
        "description": "Clickjacking possible",
        "evidence": "No X-Frame-Options header",
        "asset": "https://example.com",
        "points_deducted": 5,
        "dread_score": 7.0,
    },
]
for chunk in client.analyze_findings_stream(findings, target="example.com"):
    print(chunk, end="", flush=True)

# Non-streaming analysis
analysis = client.analyze_findings(findings, target="example.com")

# Integration pattern (like Jira/Slack/GitHub)
result = client.sync_findings(findings, target="example.com")
# {'action': 'analyzed', 'analysis': '...', 'findings_count': 1, ...}

# Structured streaming events
for event in client.sync_findings_stream(findings, target="example.com"):
    if event["type"] == "chunk":
        print(event["content"], end="")
    elif event["type"] == "done":
        print(f"\nTotal: {event['findings_count']} findings analyzed")
```

### Architecture

- **Transport**: Server-Sent Events (SSE) over HTTPS — same protocol as OpenAI streaming
- **Auth**: Auto-discovered from `/etc/.z-ai-config` (Bearer token + JWT session)
- **Protocol**: OpenAI-compatible `chat/completions` endpoint with `stream: true`
- **DREAD Handling**: Automatically averages dict-form DREAD scores (from cloud-recon) and passes float-form scores (from other modules)
- **Finding Cap**: Prompts are capped at 50 findings to stay within context limits
- **Dependencies**: Zero — pure Python stdlib (`urllib`, `json`, `ssl`)

## Modules

| Module | ID | Description |
|--------|----|-------------|
| **RECON** | `recon` | 13-category surface reconnaissance (DNS, ports, TLS, headers, tech, WAF, cookies, CORS) |
| **AUTH BYPASS** | `auth` | 15 auth bypass techniques (header injection, method tampering, path traversal, IDOR) |
| **CHAIN HUNTER** | `chain` | SSRF + redirect chain hunting (cloud metadata, open redirects) |
| **BOT HUNTER** | `bot` | C2 / bot infrastructure detection + honeypot identification |
| **GORGON ULTRA** | `gorgon` | AI red team (SQLi, XSS, path traversal, HTTP methods, content-type) |
| **OBLIVION** | `oblivion` | 23-stage deep analysis with DREAD scoring (info disclosure, JS secrets, deep headers) |
| **VIBESEC** | `vibesec` | AI/vibe-coding vulnerability benchmark (100-point score, A+–F grades, GitHub badge) |
| **NHI GRAPH** | `nhi` | Non-Human Identity detection (cloud metadata SSRF, leaked tokens, credential files) |
| **HOST AUDIT** | `host` | Local machine audit (open ports, firewall, SSH config, Docker, env vars) |
| **DEV SEC** | `dev` | Developer project scan (secrets, dependency audit, git config, Dockerfile analysis) |
| **DOCTOR** | `doctor` | Health check with auto-fix commands |

## Scoring

- **100-point** benchmark system
- **A+** (90+) → **F** (0–34) grades
- GitHub-ready **badge** for your README
- Per-module breakdowns with severity counts

## Integrations

| Integration | Class | Purpose |
|-------------|-------|---------|
| **z.ai Live Stream** | `ZAIStreamClient` | Real-time AI analysis via SSE streaming |
| **Jira** | `JiraClient` | Create/update Jira issues from findings |
| **Slack** | `SlackClient` | Send finding alerts and scan summaries |
| **GitHub** | `GitHubClient` | Create issues, PR comments, SARIF uploads |

## Output

Rich terminal UI with:
- Color-coded severity tables
- Module-by-module breakdown
- Progress spinners
- Score bars and grade indicators
- JSON export for CI/CD integration
- z.ai streaming AI analysis

## Requirements

- Python 3.8+
- No other dependencies (stdlib-only networking)
- `rich` for terminal UI (auto-installed)

## License

MIT
