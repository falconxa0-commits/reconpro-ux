# ReconPro Enterprise

> **Eight Blades. One Target. One Verdict.**

The full-spectrum security reconnaissance platform. 8 scanning modules, one CLI command.

## Installation

```bash
pip install reconpro
```

Or from source:

```bash
git clone https://github.com/reconpro-security/reconpro.git
cd reconpro
pip install .
```

## Quick Start

```bash
# Scan with default modules (recon, vibesec, auth, chain, oblivion)
reconpro example.com

# Run all 8 modules
reconpro example.com --all

# Pick specific modules
reconpro example.com --modules recon,auth,nhi

# Quick VibeSec benchmark only
reconpro vibesec example.com

# JSON output
reconpro example.com --json -o report.json

# Skip TLS verification
reconpro example.com --insecure

# Adjust timeout and rate limit
reconpro example.com --timeout 5 --rate-limit 5
```

## Modules

| Module | ID | Description |
|--------|----|-------------|
| **RECON** | `recon` | 13-category surface reconnaissance (DNS, ports, TLS, headers, tech, WAF, cookies, CORS) |
| **AUTH BYPASS** | `auth` | 15 auth bypass techniques (header injection, method tampering, path traversal, IDOR) |
| **CHAIN HUNTER** | `chain` | SSRF + redirect chain hunting (cloud metadata, open redirects) |
| **BOT HUNTER** | `bot` | C2 / bot infrastructure detection + honeypot identification |
| **GORGON ULTRA** | `gorgon` | AI red team (SQLi, XSS, path traversal, HTTP methods, content-type) |
| **OBLIVION** | `oblivion` | 23-stage deep analysis with DREAD scoring (info disclosure, JS secrets, deep headers) |
| **VIBESEC** | `vibesec` | AI/vibe-coding vulnerability benchmark (100-point score, A+–F grades, GitHub badge) |
| **NHI GRAPH** | `nhi` | Non-Human Identity detection (cloud metadata SSRF, leaked tokens, credential files) |

## Scoring

- **100-point** benchmark system
- **A+** (90+) → **F** (0–34) grades
- GitHub-ready **badge** for your README
- Per-module breakdowns with severity counts

## Output

Rich terminal UI with:
- Color-coded severity tables
- Module-by-module breakdown
- Progress spinners
- Score bars and grade indicators
- JSON export for CI/CD integration

## Requirements

- Python 3.8+
- No other dependencies (stdlib-only networking)
- `rich` for terminal UI (auto-installed)

## License

MIT